﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp27
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string inputString = textBox1.Text.ToLower(); 
            int vowelCount = 0; 
            Dictionary<char, int> vowelDistribution = new Dictionary<char, int>(); 

            foreach (char c in inputString)
            {
                if ("aeiouy".Contains(c))
                {
                    vowelCount++;

                    if (vowelDistribution.ContainsKey(c))
                    {
                        vowelDistribution[c]++;
                    }
                    else
                    {
                        vowelDistribution.Add(c, 1);
                    }
                }
            }

       
            textBox2.Text = vowelCount.ToString();

            foreach (KeyValuePair<char, int> pair in vowelDistribution)
            {
                textBox3.Text += pair.Key + ": " + pair.Value + Environment.NewLine;
            }
        }
    }
}
